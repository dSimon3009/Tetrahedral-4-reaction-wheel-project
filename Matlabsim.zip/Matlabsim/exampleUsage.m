%% exampleUsage.m
%  Demonstrates how to call plotAngularError and animate3D
%  after running your simulation.

%% --- 1. Set up simulation parameters ---------------------------------
dt    = 0.1;
tSpan = 0:dt:500;                             % adjust duration as needed
omega = 0.0011288;                            % target spin rate [rad/s]

% Initial state: identity quaternion + zero angular velocity
state0  = [1 0 0 0,  0 0 0];                 % [q0 q1 q2 q3, wx wy wz]

% Cube inertia (uniform cube, side length L, mass m)
m = 1;  L = 1;
Icube = (m*L^2/6) * eye(3);

% Controller gains [Kp, Kd]
K = [2, 3];                                   % tune as needed

%% --- 2. Build qd schedule and simulate --------------------------------
qd = buildQd(tSpan, dt, state0, Icube, K);

% If using your class-based simulate(), assign qd to the object:
%   obj.qd = qd;
%   obj.simulate();
%   stateS = obj.stateS;

% For standalone use, buildQd already produces stateS internally.
% Re-run a quick simulation here to have stateS available:
N      = length(tSpan);
stateS = zeros(N, 7);
stateS(1,:) = state0;
for a = 1:N-1
    stateS(a+1,:) = RK4(@dynamics, tSpan(a), dt, ...
                         stateS(a,:), Icube, qd(a,:), K);
    stateS(a+1,1:4) = stateS(a+1,1:4) / norm(stateS(a+1,1:4));
end

%% --- 3. Plot the angular error over time ------------------------------
plotAngularError(tSpan, stateS, omega);
%  -> Opens a 2D figure: angle (degrees) vs time (seconds).
%     You should see the error drop from ~90° toward 0° and track.

%% --- 4. Animate the 3D tracking visualisation -------------------------
%  skipFrames = 10 means render every 10th frame (faster playback)
animate3D(tSpan, stateS, omega, 10);
%  -> Opens a 3D figure with:
%       - Blue arrow  = body axis [0,0,1] rotated by current quaternion
%       - Red arrow   = spinning target axis
%       - Magenta arc = angular gap between them
%       - Dashed circle = path traced by target tip in xy-plane
