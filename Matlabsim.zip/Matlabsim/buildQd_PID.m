function [qd] = buildQd(tSpan, dt, state0, inertia, K)
% buildQd  Build a desired-quaternion schedule with PID tracking.
%
%   qd = buildQd(tSpan, dt, state0, inertia, K)
%
%   INPUTS
%     tSpan   - (1 x N) time vector  [s]
%     dt      - scalar time step      [s]
%     state0  - (1 x 7) initial state [q0 q1 q2 q3  wx wy wz]
%     inertia - (3 x 3) inertia matrix of the cube
%     K       - (1 x 3) controller gains [Kp, Kd, Ki]
%               Kp = proportional (attitude error)
%               Kd = derivative   (angular velocity damping)
%               Ki = integral     (accumulated error correction)
%
%               If K has only 2 elements, Ki defaults to 0 (pure PD).
%
%   OUTPUT
%     qd - (N x 4) desired quaternion at every time step

    omega = 0.0011288;
    N     = length(tSpan);

    % Handle legacy 2-element K (pure PD, no integral)
    if length(K) < 3
        K(3) = 0;
    end

    qd     = zeros(N, 4);
    stateS = zeros(N, length(state0) + 3);    % append 3 integral states
    stateS(1, 1:length(state0)) = state0;
    % stateS columns: [q0 q1 q2 q3 wx wy wz  intX intY intZ]
    dt = 0;
    for a = 1:N
        t = dt + 0.1;
        dt = t;

        % Target direction at time t
        tgtDir = [-sin(omega*t), cos(omega*t), 0];

        % Desired quaternion: rotation from [0,0,1] to target
        qd(a,:) = quatFromTwoVec([0, 0, 1], tgtDir);

        % Advance simulation one step with PID dynamics
        if a < N
            stateS(a+1,:) = RK4(@dynamicsPID, tSpan(a), dt, ...
                                 stateS(a,:), inertia, qd(a,:), K);
            % Re-normalise quaternion
            stateS(a+1,1:4) = stateS(a+1,1:4) / norm(stateS(a+1,1:4));
        end
    end
end


%% ======================================================================
%  PID DYNAMICS — replaces the original PD-only dynamics
%% ======================================================================

function [dX] = dynamicsPID(t, X, I, qd, K)
% dynamicsPID  Rigid body rotational dynamics with PID quaternion control.
%
%   State X = [q(1:4), w(1:3), intErr(1:3)]   (10 elements)
%
%   K = [Kp, Kd, Ki]

    q      = X(1:4);
    w      = X(5:7);
    intErr = X(8:10);       % accumulated quaternion-error integral

    % Omega matrix for quaternion derivative
    omegaw = [
        0,    -w(1), -w(2), -w(3);
        w(1),  0,     w(3), -w(2);
        w(2), -w(3),  0,     w(1);
        w(3),  w(2),  w(1),  0   ];

    % Quaternion error
    qConj = [q(1); -q(2); -q(3); -q(4)];
    qErr  = pq(qd, qConj);
    errVec = qErr(2:4);     % vector part of the error quaternion

    % --- PID torque ----------------------------------------------------
    %   P  = -Kp * errVec        (drives error to zero)
    %   D  = -Kd * w             (damps angular velocity)
    %   I  = -Ki * intErr        (eliminates steady-state offset)
    T = -K(1)*errVec(:) - K(2)*w(:) - K(3)*intErr(:);

    % Quaternion derivative
    dq = -(1/2) * pq(omegaw, q);

    % Angular velocity derivative (Euler's equation)
    dw = I.\(-1*cartesianCrossProduct(w', I*w') + T)';

    % Integral state derivative (the error being accumulated)
    disp(dq')
    disp(dw')
    dIntErr = errVec(:)';
    disp(dIntErr)

    dX = [dq', dw', dIntErr];
end


%% ======================================================================
%  HELPER FUNCTIONS
%% ======================================================================

function qr = quatFromTwoVec(a, b)
    a = a / norm(a);
    b = b / norm(b);
    d = dot(a, b);
    if d > 0.999999
        qr = [1, 0, 0, 0]; return;
    elseif d < -0.999999
        perp = cross([1,0,0], a);
        if norm(perp) < 1e-6, perp = cross([0,1,0], a); end
        perp = perp / norm(perp);
        qr = [0, perp]; return;
    end
    ax = cross(a, b);
    qr = [1 + d, ax];
    qr = qr / norm(qr);
end

function vRot = quatRotVec(q, v)
    qv    = [0, v(:)'];
    qConj = [q(1), -q(2), -q(3), -q(4)];
    tmp   = quatMul(q, qv);
    res   = quatMul(tmp, qConj);
    vRot  = res(2:4);
end

function r = quatMul(p, q)
    r = [p(1)*q(1)-p(2)*q(2)-p(3)*q(3)-p(4)*q(4), ...
         p(1)*q(2)+p(2)*q(1)+p(3)*q(4)-p(4)*q(3), ...
         p(1)*q(3)-p(2)*q(4)+p(3)*q(1)+p(4)*q(2), ...
         p(1)*q(4)+p(2)*q(3)-p(3)*q(2)+p(4)*q(1)];
end

function r = pq(a, b)
    r = quatMul(a(:)', b(:)');
    r = r(:);
end

function c = cartesianCrossProduct(a, b)
    c = cross(a, b);
    c = c(:);
end

function [Xn1] = RK4(dynamicsFn, t, dt, Xn0, varargin)
    k1 = dynamicsFn(t,        Xn0,            varargin{:});
    k2 = dynamicsFn(t+dt/2,   Xn0+dt*k1/2,   varargin{:});
    k3 = dynamicsFn(t+dt/2,   Xn0+dt*k2/2,   varargin{:});
    k4 = dynamicsFn(t+dt,     Xn0+dt*k3,      varargin{:});
    Xn1 = Xn0 + dt*(k1 + 2*k2 + 2*k3 + k4)/6;
end
