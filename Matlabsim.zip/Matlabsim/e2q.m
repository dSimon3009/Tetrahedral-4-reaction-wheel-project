function [q] = e2q(e)
%%% e2q
%       Convert euler angles to quaternions
%            e(1) = Yaw
%            e(2) = Pitch
%            e(3) = Roll
% 
%        Quaternion format
%            q(1) = scalar
%            q(2:4) = vector

[rows, cols] = size(e);

q = zeros (rows, 4);

for i = 1:rows
    q(i,:) = [
        cos(e(i,3)/2).*cos(e(i,2)/2).*cos(e(i,1)/2) + sin(e(i,3)/2).*sin(e(i,2)/2).*sin(e(i,1)/2),...
        sin(e(i,3)/2).*cos(e(i,2)/2).*cos(e(i,1)/2) - cos(e(i,3)/2).*sin(e(i,2)/2).*sin(e(i,1)/2),...
        cos(e(i,3)/2).*sin(e(i,2)/2).*cos(e(i,1)/2) + sin(e(i,3)/2).*cos(e(i,2)/2).*sin(e(i,1)/2),...     
        cos(e(i,3)/2).*cos(e(i,2)/2).*sin(e(i,1)/2) - sin(e(i,3)/2).*sin(e(i,2)/2).*cos(e(i,1)/2),...    
    ];
end


end