disp("Start")

%Time span
dt = 1e-1;
tSpan = 0:dt:100;

%Initial condition
e0=[0,1.57,0];
q0 = e2q(e0);
w0 = [0,0,0];
state0 = [q0, w0];
omega = 0.0011288;

N = length(tSpan);
dirs = zeros(N, 3);
    for k = 1:N
    t = tSpan(k);
    Omega = -0.0011288;
    dirs(k,:) = [sin(Omega*t), -cos(Omega*t), 0];
    %disp(dirs(k,:))                
    end

K=[0.1,0.5,0.0075];
vertices = [
    -1 -1 -1;
    -1 1 -1;
    1 1 -1;
    1 -1 -1;
    -1 -1 1;
    -1 1 1;
    1 1 1;
    1 -1 1
    ];
faces = [
    1 2 6 5;
    2 3 7 6;
    3 4 8 7;
    4 1 5 8;
    1 2 3 4;
    5 6 7 8
    ];

% Vertices (square base + apex)
V = [
    -1 -1 0;   % base
     1 -1 0;
     1  1 0;
    -1  1 0;
     0  0 2    % apex
];

% Faces
F2 = [
    1 2 5;
    2 3 5;
    3 4 5;
    4 1 5;
    1 2 3;
    1 3 4
];

color = [0 0.5 0];
inertia = diag([1 1 1]);
BLOCK = block(state0, inertia, tSpan, dt, K, vertices, V,faces, F2,color,dirs);
BLOCK.simulate();
BLOCK.animate();

disp("Done")
