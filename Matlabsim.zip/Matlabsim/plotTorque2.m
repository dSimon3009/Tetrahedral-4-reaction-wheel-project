function plotTorque(tSpan, T_history)

    % Force correct shapes
    tSpan = tSpan(:);   % make column vector

    % Compute magnitude properly
    mag = vecnorm(T_history, 2, 2);  % Nx1

    % Debug check
    disp(size(mag))   % should be [N 1]

    figure('Name','Torque','NumberTitle','off');
    plot(tSpan, mag, 'b-', 'LineWidth', 1.5);

    xlabel('Time [s]');
    ylabel('Torque Magnitude');
    title('Torque vs Time');
    grid on;

end