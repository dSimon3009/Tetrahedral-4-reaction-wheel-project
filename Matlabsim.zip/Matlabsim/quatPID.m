%% ======================================================================
%  quatPID.m
%  Drop-in PID replacement for quatETC.
%  Use this in your existing class if you prefer to keep your simulate()
%  and dynamics() structure unchanged apart from the controller.
%% ======================================================================

function [T, dIntErr] = quatPID(q, qd, w, K, intErr)
% quatPID  PID quaternion error torque controller.
%
%   [T, dIntErr] = quatPID(q, qd, w, K, intErr)
%
%   INPUTS
%     q      - (4x1 or 1x4) current quaternion
%     qd     - (4x1 or 1x4) desired quaternion
%     w      - (3x1 or 1x3) current angular velocity
%     K      - [Kp, Kd, Ki]  controller gains
%     intErr - (3x1 or 1x3) current integral of the error
%
%   OUTPUTS
%     T      - (3x1) commanded torque
%     dIntErr- (3x1) derivative of integral state (= errVec, to be
%              integrated externally by your RK4)
%
%   COMPARISON WITH THE ORIGINAL quatETC:
%
%     quatETC (PD only):    T = -Kp * errVec - Kd * w
%     quatPID (PID):        T = -Kp * errVec - Kd * w - Ki * intErr
%                                                        ^^^^^^^^^^^^
%                                              this term kills the
%                                              steady-state offset
%
%   The integral term accumulates the quaternion vector error over time.
%   When tracking a moving target, the PD terms alone need a nonzero
%   error to produce the torque required for continuous rotation.
%   The integral builds up until it supplies that torque itself,
%   driving the remaining error to zero.

    q  = q(:);
    w  = w(:);
    intErr = intErr(:);

    % Quaternion error: qErr = qd * conj(q)
    qConj = [q(1); -q(2); -q(3); -q(4)];
    qErr  = pq(qd, qConj);
    errVec = qErr(2:4);       % vector part

    % PID torque
    T = -K(1)*errVec - K(2)*w - K(3)*intErr;

    % Error derivative for integral accumulation
    dIntErr = errVec;
end

%{
%% ======================================================================
%  Updated dynamics function for use with quatPID
%  The state vector is extended: X = [q(4), w(3), intErr(3)] = 10 states
%% ======================================================================

function [dX] = dynamicsPID(obj, t, X, I, qd, K)
    q      = X(1:4);
    w      = X(5:7);
    intErr = X(8:10);

    omegaw = [
        0,    -w(1), -w(2), -w(3);
        w(1),  0,     w(3), -w(2);
        w(2), -w(3),  0,     w(1);
        w(3),  w(2),  w(1),  0   ];

    [T, dIntErr] = quatPID(q, qd, w, K, intErr);

    dq = (1/2) * pq(omegaw, q);
    dw = I \ (-1*cartesianCrossProduct(w', I*w') + T)';

    dX = [dq', dw', dIntErr'];
end


%% ======================================================================
%  Updated simulate function
%  state0 must now be 10 elements: [q0 q1 q2 q3  wx wy wz  0 0 0]
%                                                            ^^^^^^^
%                                                    integral states
%                                                    (start at zero)
%% ======================================================================

function [] = simulatePID(obj)
    obj.state0 = [obj.state0(1:7), 0, 0, 0];  % extend if needed
    obj.stateS = zeros(length(obj.tSpan), length(obj.state0));
    obj.stateS(1,:) = obj.state0;

    for a = 1:length(obj.tSpan)-1
        obj.stateS(a+1,:) = RK4(@obj.dynamicsPID, obj.tSpan(a), ...
                                 obj.dt, obj.stateS(a,:), ...
                                 obj.inertia, obj.qd(a,:), obj.K);
        % Re-normalise quaternion
        obj.stateS(a+1,1:4) = obj.stateS(a+1,1:4) / ...
                               norm(obj.stateS(a+1,1:4));
    end
end


%% ======================================================================
%  Helpers (same as before)
%% ======================================================================

function r = pq(a, b)
    a = a(:)'; b = b(:)';
    r = [a(1)*b(1)-a(2)*b(2)-a(3)*b(3)-a(4)*b(4); ...
         a(1)*b(2)+a(2)*b(1)+a(3)*b(4)-a(4)*b(3); ...
         a(1)*b(3)-a(2)*b(4)+a(3)*b(1)+a(4)*b(2); ...
         a(1)*b(4)+a(2)*b(3)-a(3)*b(2)+a(4)*b(1)];
end

function c = cartesianCrossProduct(a, b)
    c = cross(a, b); c = c(:);
end

function [Xn1] = RK4(dynamicsFn, t, dt, Xn0, varargin)
    k1 = dynamicsFn(t,        Xn0,            varargin{:});
    k2 = dynamicsFn(t+dt/2,   Xn0+dt*k1/2,   varargin{:});
    k3 = dynamicsFn(t+dt/2,   Xn0+dt*k2/2,   varargin{:});
    k4 = dynamicsFn(t+dt,     Xn0+dt*k3,      varargin{:});
    Xn1 = Xn0 + dt*(k1 + 2*k2 + 2*k3 + k4)/6;
end
%}