%% ======================================================================
%  plotAngularError.m
%  Plots the angular difference (in degrees) between the body axis and
%  the spinning target axis over the entire simulation.
%% ======================================================================

function plotAngularError(tSpan, stateS, omega)
% plotAngularError  Graph the angle separating the two axes over time.
%
%   plotAngularError(tSpan, stateS, omega)
%
%   INPUTS
%     tSpan  - (1 x N) time vector [s]
%     stateS - (N x 7) simulated state history [q0 q1 q2 q3 wx wy wz]
%     omega  - scalar spin rate of the target axis [rad/s]
%              (default 0.0011288 if omitted)
%
%   The body axis is [0,0,1] rotated by the quaternion in stateS.
%   The target axis is [0,1,0] spinning around z at omega rad/s.

    if nargin < 3
        omega = 0.0011288;
    end

    N        = length(tSpan);
    angDeg   = zeros(1, N);

    for k = 1:N
        % --- Current body axis in world frame ---
        q        = stateS(k, 1:4);
        bodyAxis = quatRotVec(q, [0, 0, 1]);

        % --- Target direction at this instant ---
        t      = tSpan(k);
        tgtDir = [sin(omega*t),  -cos(omega*t),  0];

        % --- Angular separation ---
        %     theta = acos( dot(a,b) / (|a|*|b|) )
        %     Both are unit vectors, but normalise for safety.
        bodyAxis = bodyAxis / norm(bodyAxis);
        tgtDir   = tgtDir   / norm(tgtDir);
        cosAng   = dot(bodyAxis, tgtDir);
        cosAng   = max(-1, min(1, cosAng));   % clamp for numerical safety
        angDeg(k) = acosd(cosAng);            % result in degrees
    end

    % --- Plot ---
    figure('Name','Angular Error','NumberTitle','off');
    plot(tSpan/2.95, angDeg, 'b-', 'LineWidth', 1.5);
    xlabel('Time [s]');
    ylabel('Angular Difference [deg]');
    title('Angular Separation Between Body Axis and Spinning Target');
    grid on;
    yline(0, 'r--', 'Perfect Alignment', 'LineWidth', 1);
    ylim([0, max(angDeg)*1.1 + 1]);

end


%% ======================================================================
%  animate3D.m
%  3D animated figure showing both vectors and the angular arc between
%  them as they evolve in time.
%% ======================================================================
%{
function animate3D(tSpan, stateS, omega, skipFrames)
% animate3D  Animated 3D visualisation of both axes and their angular gap.
%
%   animate3D(tSpan, stateS, omega, skipFrames)
%
%   INPUTS
%     tSpan      - (1 x N) time vector [s]
%     stateS     - (N x 7) simulated state history
%     omega      - spin rate of the target [rad/s] (default 0.0011288)
%     skipFrames - render every Nth frame for speed  (default 1)

    if nargin < 3 || isempty(omega),      omega = 0.0011288; end
    if nargin < 4 || isempty(skipFrames), skipFrames = 1;     end

    N = length(tSpan);

    % --- Set up figure -------------------------------------------------
    fig = figure('Name','3D Axis Tracking','NumberTitle','off', ...
                 'Color','w','Position',[100 100 800 700]);
    ax  = axes('Parent',fig);
    hold(ax,'on');  grid(ax,'on');  axis(ax,'equal');
    xlabel(ax,'X'); ylabel(ax,'Y'); zlabel(ax,'Z');
    title(ax,'Body Axis (blue) tracking Spinning Target (red)');
    view(ax, 30, 25);
    xlim(ax,[-1.5 1.5]); ylim(ax,[-1.5 1.5]); zlim(ax,[-1.5 1.5]);

    % Draw z-axis reference (the axis the target spins around)
    plot3(ax, [0 0],[0 0],[-1.4 1.4],'k--','LineWidth',0.8);
    text(ax, 0, 0, 1.5, 'Z','FontWeight','bold');

    % Draw the circular path traced by the target tip (unit circle in xy)
    th = linspace(0, 2*pi, 200);
    plot3(ax, -sin(th), cos(th), zeros(size(th)), ...
          'Color',[1 0.6 0.6],'LineStyle','--','LineWidth',0.8);

    % Graphics handles for animated objects
    hBody   = quiver3(ax,0,0,0,0,0,1, 0,'b','LineWidth',2.5, ...
                      'MaxHeadSize',0.5,'DisplayName','Body [0,0,1]');
    hTarget = quiver3(ax,0,0,0,0,1,0, 0,'r','LineWidth',2.5, ...
                      'MaxHeadSize',0.5,'DisplayName','Target');
    hArc    = plot3(ax, nan,nan,nan,'m-','LineWidth',1.5, ...
                    'DisplayName','Angular gap');
    hText   = text(ax, 1.0, -1.0, 1.3, '', 'FontSize', 12);
    legend(ax,'Location','northwest');

    % --- Animation loop ------------------------------------------------
    for k = 1:skipFrames:N
        if ~ishandle(fig), return; end        % user closed the window

        t = tSpan(k);

        % Body axis
        q    = stateS(k,1:4);
        bDir = quatRotVec(q, [0,0,1]);
        bDir = bDir / norm(bDir);

        % Target axis
        tDir = [-sin(omega*t), cos(omega*t), 0];

        % Update quiver arrows (origin at 0,0,0)
        set(hBody,  'UData',bDir(1),'VData',bDir(2),'WData',bDir(3));
        set(hTarget,'UData',tDir(1),'VData',tDir(2),'WData',tDir(3));

        % Arc between the two vectors (great-circle interpolation)
        angRad = acos(max(-1, min(1, dot(bDir, tDir))));
        if angRad > 1e-4
            nPts   = 30;
            arcPts = zeros(nPts, 3);
            for j = 1:nPts
                frac      = (j-1)/(nPts-1);    % 0 to 1
                interp    = sin((1-frac)*angRad)/sin(angRad) * bDir + ...
                            sin(frac*angRad)/sin(angRad)     * tDir;
                arcPts(j,:) = 0.4 * interp / norm(interp);  % at radius 0.4
            end
            set(hArc,'XData',arcPts(:,1), ...
                     'YData',arcPts(:,2), ...
                     'ZData',arcPts(:,3));
        else
            set(hArc,'XData',nan,'YData',nan,'ZData',nan);
        end

        % Annotation
        set(hText,'String', ...
            sprintf('t = %.2f s\n\\Delta\\theta = %.2f°', ...
                    t, rad2deg(angRad)));

        drawnow limitrate;
    end
end
%}

%% ======================================================================
%  SHARED HELPER (same as in buildQd)
%% ======================================================================
%{
function vRot = quatRotVec(q, v)
    qv    = [0, v(:)'];
    qConj = [q(1), -q(2), -q(3), -q(4)];
    tmp   = pq(q, qv);
    res   = pq(tmp, qConj);
    vRot  = res(2:4);
end

function r = quatMul(p, q)
    r = [p(1)*q(1)-p(2)*q(2)-p(3)*q(3)-p(4)*q(4), ...
         p(1)*q(2)+p(2)*q(1)+p(3)*q(4)-p(4)*q(3), ...
         p(1)*q(3)-p(2)*q(4)+p(3)*q(1)+p(4)*q(2), ...
         p(1)*q(4)+p(2)*q(3)-p(3)*q(2)+p(4)*q(1)];
end
%}