function [pq] = pq(a, b)
    a = a(:);  b = b(:);    % force 4x1
    pq = [a(1)*b(1) - a(2)*b(2) - a(3)*b(3) - a(4)*b(4);
         a(1)*b(2) + a(2)*b(1) + a(3)*b(4) - a(4)*b(3);
         a(1)*b(3) - a(2)*b(4) + a(3)*b(1) + a(4)*b(2);
         a(1)*b(4) + a(2)*b(3) - a(3)*b(2) + a(4)*b(1)];
%%% QP
%{ 
Kronecker product, multiplies two quaternions p and q

pq = [
    p(1)*q(1) - p(2)*q(2) - p(3)*q(3) - p(4)* q(4);
    p(1)*q(2) + p(2)*q(1) + p(3)*q(4) - p(4)* q(3);
    p(1)*q(3) - p(2)*q(4) + p(3)*q(1) + p(4)* q(2);
    p(1)*q(4) + p(2)*q(3) - p(3)*q(2) + p(4)* q(1);
];
%}
end