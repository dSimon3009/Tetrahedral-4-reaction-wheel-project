function [qd] = buildQd(tSpan, dt, state0, inertia, K)
% buildQd  Build a desired-quaternion schedule by iteratively simulating
%          the body and recomputing the target alignment at every time step.
%
%   qd = buildQd(tSpan, dt, state0, inertia, K)
%
%   The body axis a0 = [0,0,1] must be steered to track a target axis
%   that starts at [0,1,0] and spins around the z-axis at
%   omega = 0.0011288 rad/s.
%
%   At each time step the function:
%     1. Determines the current body orientation from the simulated state.
%     2. Computes the instantaneous target direction.
%     3. Builds the desired quaternion that would align [0,0,1] with that
%        target direction.
%     4. Advances the simulation one RK4 step using the dynamics/torque
%        controller, so the next step sees the updated orientation.
%
%   INPUTS
%     tSpan   - (1 x N) time vector  [s]
%     dt      - scalar time step      [s]
%     state0  - (1 x 7) initial state [q0 q1 q2 q3  wx wy wz]
%               (unit quaternion + angular velocity)
%     inertia - (3 x 3) inertia matrix of the cube
%     K       - (1 x 2) controller gains [Kp, Kd]
%
%   OUTPUT
%     qd      - (N x 4) desired quaternion at every time step
%               Row a is used by simulate() as  obj.qd(a,:)
    %disp(state0)
    omega = -0.011288;            % target spin rate [rad/s]
    N     = length(tSpan);
        % Handle legacy 2-element K (pure PD, no integral)
    if length(K) < 3
        K(3) = 0;
    end
    % ---------- pre-allocate -------------------------------------------
    qd     = zeros(N, 4);
    stateS = zeros(N, length(state0) + 3);    % append 3 integral states
    stateS(1, 1:length(state0)) = state0;
    %disp(stateS)
    dt = 0;
    % ---------- step-by-step build -------------------------------------
    for a = 1:N

        t = dt + 0.1;
        dt = t;

        % --- 1. Target direction at time t ---
        %     [0,1,0] rotated about z by omega*t
        tgtDir = [sin(omega*t),  -cos(omega*t),  0];

        % --- 2. Current body axis [0,0,1] in the world frame -----------
        %     Rotate [0,0,1] by the body's current quaternion.
        %     (Used here to monitor alignment; the controller works
        %      on the full quaternion error qd * conj(q).)
        qCur     = stateS(a, 1:4);
        bodyAxis = quatRotVec(qCur, [0, 0, 1]);

        % --- 3. Desired quaternion: rotation taking [0,0,1] -> tgtDir --
        %     This is the ABSOLUTE target orientation for the controller.
        %     It is recomputed every step so it tracks the spinning target
        %     while the body is in motion.
        qd(a,:) = -quatFromTwoVec([0, 0, 1], tgtDir);

        % --- 4. Advance simulation one step ----------------------------
        if a < N
            %disp(stateS(a+1,:))
            stateS(a+1,:) = RK4(@dynamicsPID, tSpan(a), dt, ...
                                 stateS(a,:), inertia, qd(a,:), K);
            % Re-normalise quaternion
            stateS(a+1,1:4) = stateS(a+1,1:4) / norm(stateS(a+1,1:4));
            %disp(stateS(a+1,1:4))
        end
    end

    % ---- (Optional) display the schedule in the mask format -----------
    %       shown in the problem statement.  Uncomment to print.
    % fprintf('qd schedule (mask format):\n');
    % for a = 1:N
    %     fprintf('  [%.6f %.6f %.6f %.6f] .* (tSpan > %.4f)\n', ...
    %              qd(a,:), tSpan(a));
    % end
end


%% ======================================================================
%  LOCAL HELPER FUNCTIONS
%  ======================================================================

function vRot = quatRotVec(q, v)
% quatRotVec  Rotate vector v by unit quaternion q = [q0 q1 q2 q3].
%   Uses  v' = q * [0;v] * conj(q)  via the quaternion product.
    qv    = [0, v(:)'];                       % pure quaternion
    qConj = [q(1), -q(2), -q(3), -q(4)];
    tmp   = qp(q, qv);
    res   = qp(tmp, qConj);
    vRot  = res(2:4);
end

function qr = quatFromTwoVec(a, b)
% quatFromTwoVec  Quaternion that rotates unit vector a onto unit vector b.
%   Returns q = [q0 q1 q2 q3] (scalar-first).
    a = a / norm(a);
    b = b / norm(b);
    d = dot(a, b);

    if d > 0.999999
        % Vectors are parallel -> identity quaternion
        qr = [1, 0, 0, 0];
        return;
    elseif d < -0.999999
        % Vectors are anti-parallel -> 180-deg rotation about any
        % perpendicular axis
        perp = cross([1,0,0], a);
        if norm(perp) < 1e-6
            perp = cross([0,1,0], a);
        end
        perp = perp / norm(perp);
        qr = [0, perp];                      % cos(pi/2)=0, sin(pi/2)=1
        return;
    end

    ax = cross(a, b);
    qr = [1 + d,  ax];
    qr = qr / norm(qr);                      % normalise
end

function r = quatMul(p, q)
% quatMul  Hamilton product of two quaternions (scalar-first).
    r = [p(1)*q(1) - p(2)*q(2) - p(3)*q(3) - p(4)*q(4), ...
         p(1)*q(2) + p(2)*q(1) + p(3)*q(4) - p(4)*q(3), ...
         p(1)*q(3) - p(2)*q(4) + p(3)*q(1) + p(4)*q(2), ...
         p(1)*q(4) + p(2)*q(3) - p(3)*q(2) + p(4)*q(1)];
end


%% ======================================================================
%  DYNAMICS AND CONTROLLER  (from the problem statement)
%  ======================================================================

function [dX] = dynamicsPID(t, X, I, qd, K)
    %disp(t)
    %disp(X)
    %disp(I)
    %disp(qd)
    %disp(K)
    q      = X(1:4);
    w      = X(5:7);
    intErr = X(8:10); 

    omegaw = [
        0,    -w(1), -w(2), -w(3);
        w(1),  0,     w(3), -w(2);
        w(2), -w(3),  0,     w(1);
        w(3),  w(2),  w(1),  0   ];

    qConj = [q(1); -q(2); -q(3); -q(4)];
    qErr  = qp(qd, qConj);
    errVec = qErr(2:4);     % vector part of the error quaternion

    % --- PID torque ----------------------------------------------------
    %   P  = -Kp * errVec        (drives error to zero)
    %   D  = -Kd * w             (damps angular velocity)
    %   I  = -Ki * intErr        (eliminates steady-state offset)
    T = -K(1)*errVec(:) - K(2)*w(:) - K(3)*intErr(:);

    dq = (1/2) * (omegaw .* q);
    dw = I \ (-1*cartesianCrossProduct(w, I*w) + T);
    disp(dq)
    disp(dw)
    dIntErr = errVec(:)';
    disp(dIntErr)
    dX = [dq', dw', dIntErr'];
end

%function [T] = quatETC(q, qd, w, K)
    %qConj = [q(1); -q(2); -q(3); -q(4)];
    %qErr  = (qp(qd, qConj))';
    %T     = -K(1)*qErr(2:4) - K(2)*w;
%end

%function r = qp(a, b)
% qp  Quaternion product (scalar-first convention).
    %r = quatMul(a(:)', b(:)');
    %r = r(:);   % return as column to match original usage
%end

%function c = cartesianCrossProductP(a, b)
% cartesianCrossProductP  Standard 3D cross product.
    %c = cross(a, b);
    %c = c(:);   % column
%end


%% ======================================================================
%  RK4 INTEGRATOR  (from the problem statement)
%  ======================================================================

%function [Xn1] = RK4(dynamicsFn, t, dt, Xn0, varargin)
    %k1 = dynamicsFn(t,        Xn0,            varargin{:});
    %k2 = dynamicsFn(t+dt/2,   Xn0+dt*k1/2,   varargin{:});
    %k3 = dynamicsFn(t+dt/2,   Xn0+dt*k2/2,   varargin{:});
    %k4 = dynamicsFn(t+dt,     Xn0+dt*k3,      varargin{:});
    %Xn1 = Xn0 + dt*(k1 + 2*k2 + 2*k3 + k4)/6;
%end


function r = qp(a, b)
    r = quatMul(a(:)', b(:)');
    r = r(:);
end
function c = cartesianCrossProductP(a, b)
    c = cross(a, b);
    c = c(:);
end