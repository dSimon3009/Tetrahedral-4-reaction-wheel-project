function [qd] = buildQd(tSpan, dt, state0, inertia, K)
% buildQd  Build desired-quaternion schedule with PID tracking.
%
%   qd = buildQd(tSpan, dt, state0, inertia, K)
%
%   INPUTS
%     tSpan   - (1 x N) time vector  [s]
%     dt      - scalar time step      [s]
%     state0  - (1 x 7) initial state [q0 q1 q2 q3  wx wy wz]
%     inertia - (3 x 3) inertia matrix of the cube
%     K       - (1 x 3) controller gains [Kp, Kd, Ki]
%               If only 2 elements provided, Ki defaults to 0 (pure PD).
%
%   OUTPUT
%     qd - (N x 4) desired quaternion at every time step

    omega = -0.0011288;
    N     = length(tSpan);

    if length(K) < 3
        K(3) = 0;
    end

    qd     = zeros(N, 4);
    stateS = zeros(N, length(state0) + 3);    % append 3 integral states
    stateS(1, 1:length(state0)) = state0;
    % intErr starts at zero (columns 8:10 already zero)

    for a = 1:N
        t = tSpan(a);

        % Target direction at time t
        tgtDir = [sin(omega*t), -cos(omega*t), 0];

        qCur     = stateS(a, 1:4);
        bodyAxis = quatRotVec(qCur, [0, 0, 1]);
        % Desired quaternion: rotation from [0,0,1] to target
        qd(a,:) = -quatFromTwoVec([0, 0, 1], tgtDir);

        % Advance simulation one step
        if a < N
            stateS(a+1,:) = RK4(@dynamicsPID, tSpan(a), dt, ...
                                 stateS(a,:), inertia, qd(a,:), K);
            % Re-normalise quaternion to prevent drift
            stateS(a+1,1:4) = stateS(a+1,1:4) / norm(stateS(a+1,1:4));
        end
    end
end


%% ======================================================================
%  FIXED PID DYNAMICS
%  All vectors are explicitly forced to ROW vectors so that dX is
%  always 1 x 10, matching the row-based state in stateS.
%% ======================================================================

function [dX] = dynamicsPID(t, X, I, qd, K)
% dynamicsPID  Rigid-body rotational dynamics with PID quaternion control.
%
%   State X = [q(1x4), w(1x3), intErr(1x3)]   — always a 1x10 ROW
%
%   K = [Kp, Kd, Ki]

    % --- Extract state (all as COLUMN vectors for math) ----------------
    q      = X(1:4);    q = q(:);        % 4x1
    w      = X(5:7);    w = w(:);        % 3x1
    intErr = X(8:10);   intErr = intErr(:); % 3x1
    qd     = qd(:);                      % 4x1

    % --- Quaternion derivative -----------------------------------------
    %     dq = 0.5 * Omega(w) * q
    %     Omega is a 4x4 matrix — use MATRIX MULTIPLICATION, not pq.
    omegaw = [
        0,    -w(1), -w(2), -w(3);
        w(1),  0,     w(3), -w(2);
        w(2), -w(3),  0,     w(1);
        w(3),  w(2),  w(1),  0   ];

    dq = 0.5 * pq(omegaw, q);             % 4x4 * 4x1 = 4x1

    % --- Quaternion error (for PID controller) -------------------------
    qConj  = [q(1); -q(2); -q(3); -q(4)];
    qErr   = quatProduct(qd, qConj);     % 4x1
    errVec = qErr(2:4);                   % 3x1

    % --- PID torque ----------------------------------------------------
    T = -K(1)*errVec - K(2)*w - K(3)*intErr;   % 3x1

    % --- Angular velocity derivative (Euler's equation) ----------------
    crossTerm = cross(w, I*w);            % 3x1
    dw = I \ (-crossTerm + T);            % 3x3 \ 3x1 = 3x1

    % --- Integral state derivative -------------------------------------
    dIntErr = errVec;                     % 3x1

    % --- Assemble output as 1 x 10 ROW --------------------------------
    dX = [dq', dw', dIntErr'];            % 1x4 + 1x3 + 1x3 = 1x10
end


%% ======================================================================
%  QUATERNION PRODUCT (Hamilton product only, NOT for matrices)
%  Both inputs must be 4-element quaternions [scalar; i; j; k].
%% ======================================================================

function r = quatProduct(a, b)
    a = a(:);  b = b(:);    % force 4x1
    r = [a(1)*b(1) - a(2)*b(2) - a(3)*b(3) - a(4)*b(4);
         a(1)*b(2) + a(2)*b(1) + a(3)*b(4) - a(4)*b(3);
         a(1)*b(3) - a(2)*b(4) + a(3)*b(1) + a(4)*b(2);
         a(1)*b(4) + a(2)*b(3) - a(3)*b(2) + a(4)*b(1)];
end


%% ======================================================================
%  HELPERS
%% ======================================================================

function qr = quatFromTwoVec(a, b)
    a = a(:)'/norm(a);   b = b(:)'/norm(b);
    d = dot(a, b);
    if d > 0.999999
        qr = [1, 0, 0, 0]; return;
    elseif d < -0.999999
        perp = cross([1,0,0], a);
        if norm(perp) < 1e-6, perp = cross([0,1,0], a); end
        qr = [0, perp/norm(perp)]; return;
    end
    ax = cross(a, b);
    qr = [1 + d, ax];
    qr = qr / norm(qr);
end

function [Xn1] = RK4(dynamicsFn, t, dt, Xn0, varargin)
    k1 = dynamicsFn(t,        Xn0,            varargin{:});
    k2 = dynamicsFn(t+dt/2,   Xn0+dt*k1/2,   varargin{:});
    k3 = dynamicsFn(t+dt/2,   Xn0+dt*k2/2,   varargin{:});
    k4 = dynamicsFn(t+dt,     Xn0+dt*k3,      varargin{:});
    Xn1 = Xn0 + dt*(k1 + 2*k2 + 2*k3 + k4)/6;
end
