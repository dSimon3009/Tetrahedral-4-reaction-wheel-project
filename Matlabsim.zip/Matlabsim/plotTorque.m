function plotTorque(tSpan, T_history)

    N = length(tSpan);
    mag = zeros(N,1);   

    for k = 1:N-1
        g = T_history(k+1,:);  
        mag(k) = norm(g);
        %disp(mag(k))
    end
    %size(T_history)
    %size(mag)
    %tSpan = tSpan(:);
    %disp(mag')
    figure('Name','Torque','NumberTitle','off');
    plot(tSpan/2.95, mag','b-', 'LineWidth', 1.5);
    xlabel('Time [s]');
    ylabel('Torque Magnitude');
    title('Torque vs Time');
    grid on;

end