classdef block < handle
    properties
        state0
        stateS
        inertia
        tSpan
        dt
        qd
        K
        dirs
        vertices
        V
        F2
        faces
        color
        valueHistory
        T_history
     
        h
        h2
        h3
    end
    methods
        function obj = block(state0, inertia, tSpan, dt, K, vertices, V,faces, F2,color,dirs)

            obj.state0 = state0;
            obj.inertia = inertia;
            obj.tSpan = tSpan;
            obj.dt = dt;
            %obj.qd = qd;
            obj.K = K;
            obj.vertices = vertices;
            obj.faces = faces;
            obj.color = color;
            obj.V = V;
            obj.F2 = F2;
            obj.dirs = dirs;
            obj.draw();
        end
%{
        function [dX] = dynamics(obj, t, X, I, qd, K)
           % dynamics(t,    Xn0,    varargin{:});
            q      = X(1:4);
            w      = X(5:7);
            intErr = X(8:10);  

            omegaw = [
              0, -w(1), -w(2), -w(3);
              w(1), 0, w(3), -w(2);
              w(2), -w(3), 0,  w(1);
              w(3), w(2), w(1), 0;
            ];

            [T, dIntErr] = quatPID(q, qd, w, K, intErr);
            % T= [0 0 0]
            %disp(T)
            dq = (1/2)* pq(omegaw,q); %% < ERRORS HERE
            %disp(dq)
            dw = I\(-1*cartesianCrossProduct(w', I*w') + T)';
            %disp(dw)
            dX = [dq', dw', dIntErr'];
        end
%}
        function [dX] = dynamicsPID(obj, t, X, I, qd, K)
            % dynamicsPID  Rigid-body rotational dynamics with PID quaternion control.
            %
            %   State X = [q(1x4), w(1x3), intErr(1x3)]   — always a 1x10 ROW
            %
            %   K = [Kp, Kd, Ki]
            
                % --- Extract state (all as COLUMN vectors for math) ----------------
                q      = X(1:4);    q = q(:);        % 4x1
                w      = X(5:7);    w = w(:);        % 3x1
                intErr = X(8:10);   intErr = intErr(:); % 3x1
                qd     = qd(:);                      % 4x1
            
                % --- Quaternion derivative -----------------------------------------
                %     dq = 0.5 * Omega(w) * q
                %     Omega is a 4x4 matrix — use MATRIX MULTIPLICATION, not pq.
                omegaw = [
                    0,    -w(1), -w(2), -w(3);
                    w(1),  0,     w(3), -w(2);
                    w(2), -w(3),  0,     w(1);
                    w(3),  w(2),  w(1),  0   ];
            
                dq = 0.5 * pq(omegaw, q);             % 4x4 * 4x1 = 4x1
            
                % --- Quaternion error (for PID controller) -------------------------
                qConj  = [q(1); -q(2); -q(3); -q(4)];
                qErr   = pq(qd, qConj);     % 4x1
                errVec = qErr(2:4);                   % 3x1
            
                % --- PID torque ----------------------------------------------------
                T = -K(1)*errVec - K(2)*w - K(3)*intErr;   % 3x1
            
                % --- Angular velocity derivative (Euler's equation) ----------------
                crossTerm = cross(w, I*w);            % 3x1
                dw = I \ (-crossTerm + T);            % 3x3 \ 3x1 = 3x1
            
                % --- Integral state derivative -------------------------------------
                dIntErr = errVec;                     % 3x1
            
                % --- Assemble output as 1 x 10 ROW --------------------------------
                dX = [dq', dw', dIntErr'];            % 1x4 + 1x3 + 1x3 = 1x10
        end
        function [] = simulate(obj)

            if length(obj.K) < 3
                obj.K(3) = 0;
            end
            obj.qd = zeros(length(obj.tSpan), 4);
            obj.stateS = zeros(length(obj.tSpan), length(obj.state0) + 3);
            obj.stateS(1, 1:length(obj.state0)) = obj.state0;
            obj.valueHistory = zeros(length(obj.tSpan), length(obj.state0)+ 3);
            obj.T_history = zeros(length(obj.tSpan),3);

            
            for a = 1:length(obj.tSpan)-1
                obj.qd = buildQd_PID_fixed(obj.tSpan, obj.dt, obj.state0, obj.inertia, obj.K);
                obj.stateS(a+1,:) = RK4(@obj.dynamicsPID, obj.tSpan(a), obj.dt, obj.stateS(a,:), obj.inertia, obj.qd(a,:), obj.K);
                obj.valueHistory(a+1,:) = obj.stateS(a+1,:);
                CurrentStateS = obj.stateS(a+1,:);
                q = CurrentStateS(1:4);
                w = CurrentStateS(5:7);
                obj.T_history(a+1,:) = quatETC(q,obj.qd(a,:),w,obj.K);
            end

      % plotTorque(obj.tSpan, obj.T_history);
      %  omega = -0.0011288;
      % plotAndAnimate(obj.tSpan,obj.valueHistory,omega);

      % plotAndAnimate(obj.tSpan,obj.valueHistory,omega);

       
        
        end
        function [] = animate(obj)
            xlim([-2 2])
            ylim([-2 2])
            zlim([-2 2])
            view(-27,36)


            %disp(obj.dirs)
            
            for i = 1:length(obj.tSpan)

                rotmat = q2a(obj.stateS(i, 1:4));
                d = obj.dirs(i,:);
                %disp(d)
                obj.updateAttitude(rotmat, d);
                title(num2str(obj.tSpan(i), "%.2f"));
                
                drawnow;
                pause(1/100)
            end
        end

        function [] = updateAttitude(obj, rotmat,d)
            vNew = (rotmat*obj.vertices')';
            set(obj.h, "Vertices", vNew);
            vNew2 = (rotmat*obj.V')';
            set(obj.h2, "Vertices", vNew2);
            set(obj.h3, 'UData',d(1), 'VData',d(2), 'WData',d(3));

        end
        function [] = draw(obj)
            set(gcf, 'Color', [0 0 0])
            obj.h = patch("Faces", obj.faces, "Vertices", obj.vertices,...
               "FaceColor", obj.color);
            hold on
            obj.h2 = patch('Vertices',obj.V,'Faces',obj.F2,'FaceColor',[0.8 0.2 0.2],...
            'EdgeColor','black');
            hold on
            obj.h3 = quiver3(0,0,0, obj.dirs(1,1),obj.dirs(1,2),obj.dirs(1,3), 2, ...
                     'b','LineWidth',3,'MaxHeadSize',0.6, ...
                     'DisplayName','Spinning axis');
            hold off

            view(125,20)
            axis equal
            grid on
            rotate3d on

        end
    end
end 