function vRot = quatRotVec(q, v)
    qv    = [0, v(:)'];
    qConj = [q(1), -q(2), -q(3), -q(4)];
    tmp   = pq(q, qv);
    res   = pq(tmp, qConj);
    vRot  = res(2:4);
end
