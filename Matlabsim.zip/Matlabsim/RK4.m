function [Xn1] = RK4(dynamicsFn, t, dt, Xn0, varargin)
    k1 = dynamicsFn(t,        Xn0,            varargin{:});
    k2 = dynamicsFn(t+dt/2,   Xn0+dt*k1/2,   varargin{:});
    k3 = dynamicsFn(t+dt/2,   Xn0+dt*k2/2,   varargin{:});
    k4 = dynamicsFn(t+dt,     Xn0+dt*k3,      varargin{:});
    Xn1 = Xn0 + dt*(k1 + 2*k2 + 2*k3 + k4)/6;
end


%{
function [Xn1] = RK4(dynamics, t, dt, Xn0, varargin)

k1 = dynamics(t,    Xn0,    varargin{:});
k2 = dynamics(t+dt/2,    Xn0+dt*k1/2,    varargin{:});
k3 = dynamics(t+dt/2,    Xn0+dt*k2/2,    varargin{:});
k4 = dynamics(t+dt,    Xn0+dt*k3,    varargin{:});

Xn1 = Xn0 + dt*(k1 + 2*k2 + 2*k3 + k4)/6; 
%}